#!/bin/bash
# 在 macOS（或 GitHub Actions 的 macos-14 runner）上重链 cas XNU 内核。
#
#   用法:  ./link.sh [输出路径]        默认 ./mach.kernel
#          DRY=1 ./link.sh             只打印命令
#
# 这套件里已经包含：
#   objs/     原 macOS 构建出来的 1046 个 .o（链接顺序来自 meta/link.filelist）
#   install/  本次改过的 14 个 .o（hk_battery/hk_wifi/umi_*/HKBluetooth ...），
#             在 Linux 上用 clang 21 -target arm64-apple-ios16.5 编出来的 Mach-O arm64
#   libs/     libfirehose_kernel.a / libpthread_kext.a（内核 KPI 桩）
#   meta/     .LDFLAGS（原始链接参数）、all-alias.exp、symbolsets.plist
set -euo pipefail

KIT=$(cd "$(dirname "$0")" && pwd)
OBJ=$KIT/objs
OUT=${1:-$KIT/mach.kernel}
ROOT_OBJS=("$OBJ/lastkernelconstructor.o" "$OBJ/lastkerneldataconst.o" "$OBJ/nonlto.o" "$OBJ/version.o")

echo "[link] KIT=$KIT"
for o in "${ROOT_OBJS[@]}"; do
  [ -f "$o" ] || { echo "[link] 缺 $o" >&2; exit 1; }
done

# ---- 1) 对象列表：install/ 里有同名 .o 就替换掉原来的
LIST=$(mktemp)
while IFS= read -r rel; do
  [ -z "$rel" ] && continue
  b=$(basename "$rel")
  if [ -f "$KIT/install/$b" ]; then
    echo "$KIT/install/$b" >> "$LIST"
  else
    echo "$OBJ/$rel" >> "$LIST"
  fi
done < "$KIT/meta/link.filelist"
echo "[link] 对象 $(wc -l < "$LIST") 个 + root ${#ROOT_OBJS[@]} 个"
echo "[link] 替换进链接的: $(ls "$KIT/install" | tr '\n' ' ')"

# ---- 3) 链接参数：把原机器的绝对路径映射到本目录，去掉 -lcc_kext（末尾换成 stub 版）
FLAGS=$(tr -d '\000' < "$KIT/meta/.LDFLAGS" | sed -e "s#^xnu-clang++ *##" -e "s#/run/media/yiya/B2D847DE61D18AAD/zcode-cas#$KIT#g" \
            -e "s#/Users/yiya/cas165/cas-ios165-src#$KIT#g" \
            -e "s#$KIT/hackios-kernel-umi#$KIT#g" \
            -e "s#$KIT/xnu-src#$KIT/objs#g" \
            -e "s#$KIT/objs/xnu-8796.121.2/BUILD/obj/DEVELOPMENT_ARM64_BCM2837/#$KIT/meta/#g" \
            -e "s#$KIT/xnu-deps/sdk/iPhoneOS16.5.xnu.sdk/usr/local/lib/kernel#$KIT/libs#g" \
            -e "s#-lcc_kext##g")

CMD=(xcrun clang++ $FLAGS -L"$KIT/stub" -o "$OUT" )
CMD+=($(cat "$LIST"))
CMD+=("${ROOT_OBJS[@]}" -lfirehose_kernel -lpthread_kext -lcc_kext)

echo "[link] clang++ 参数 $(echo "${CMD[@]}" | wc -w) 个"
if [ "${DRY:-0}" = "1" ]; then
  printf '%s\n' "${CMD[@]}" | head -20
  echo "..."
  exit 0
fi

# ---- 2) 空的 libcc_kext（真库不在包里，缺的符号由它兜住）
mkdir -p "$KIT/stub" "$KIT/libs/platform"
if [ ! -f "$KIT/stub/libcc_kext.a" ]; then
  printf 'int __cc_kext_stub;\n' > "$KIT/stub/e.c"
  xcrun clang -c "$KIT/stub/e.c" -o "$KIT/stub/e.o"
  xcrun libtool -static -o "$KIT/stub/libcc_kext.a" "$KIT/stub/e.o" >/dev/null
fi

rm -f "$OUT"
"${CMD[@]}"

# ---- 4) 验收
say() { printf '[link] %s\n' "$*"; }
say "输出: $OUT ($(stat -f%z "$OUT") 字节)"
file "$OUT"
say "入口符号（应为 fffffff0074a14a8）："
xcrun nm "$OUT" | grep -E " __start$| _mach_vm_allocate$| _AppleBluetoothModule" | head -5
xcrun nm "$OUT" | grep -q "fffffff0074a14a8 S __start" \
  && say "✅ __start 地址正确" \
  || say "⚠️ __start 地址不是 fffffff0074a14a8，检查 -Wl,-image_base 是否生效"
